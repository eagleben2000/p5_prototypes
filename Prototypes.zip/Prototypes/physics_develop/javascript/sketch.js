let world;
let blackhole;
let balls = [];
let graph;

let render = function() {
  push();
  noStroke();
  fill(this.col);
  ellipse(this.pos.x, this.pos.y, 2*this.radius);
  pop();
}

function setup() {
  createCanvas(window.innerWidth, window.innerHeight);
  colorMode(HSB);
  background(0,0,10)
  world = new World();
  for (var i = 0; i < 10; i++) {
    balls.push(new PhysicsObject(random(width), random(height), random(10, 30)));
  }
  for (var i = 0; i < balls.length; i++) {
    balls[i].defineCircle(5, render);
    balls[i].setColor(color(random(255),255, 255));
    balls[i].setVelocity(p5.Vector.random2D().mult(20));
  }

  blackhole = new PhysicsObject(width/2, height/2, 500000000);

  blackhole.defineCircle(50, render);

  blackhole.setColor(color(0, 0, 0));

  world.add(balls);
  world.add([blackhole]);
  world.initAttract(500);
}

function draw() {
  //background(0,0,255);
  for (var j = 0; j < 1; j++) {
    world.update();
    blackhole.show();
    for (var i = 0; i < balls.length; i++) {
      if (balls[i].isAlive()) {
        balls[i].trace(2);
      }
    }
  }
  for (var i = 0; i < balls.length; i++) {
    if (detectCollisionPoint(blackhole, balls[i])) {
      console.log("hit blackhole");
      balls[i].kill();
    }
  }
}
