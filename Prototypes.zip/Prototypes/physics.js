function PhysicsObject(x, y, mass) {
  this.pos = createVector(x, y);
  this.mass = mass;

  this.vel = createVector(0, 0);
  this.acc = createVector(0, 0);

  this.locked = false;

  this.init = function () {
    this.update();
    this.show();
  }

  this.applyForce = function (force) {
    let f = force.copy();
    f.div(this.mass);
    this.acc.add(f);
  }
  this.lock = function (pos) {
    this.locked = true;
    if (pos) {
      this.pos = pos;
    }
  }
  this.unlock = function () {
    this.locked = false;
  }

  this.setVelocity = function (vel) {
    this.vel.add(vel);
  }
  this.getVelocity = function () {
    return this.vel.copy();
  }

  this.update = function () {
    if (!this.locked) {
      this.vel.add(this.acc);
      this.pos.add(this.vel);
      this.acc.mult(0);
    }
  }
  this.show = function () {
    let size = this.mass * 10;
    push();
    stroke(255);
    strokeWeight(size);
    point(this.pos.x,this.pos.y)
    pop();
  }

  this.bounce = function (bounce) {
    if (this.pos.x > width) {
      this.pos.x = width;
      this.vel.x *= -1;
    } else if (this.pos.x < 0) {
      this.vel.x *= -1;
      this.pos.x = 0;
    }

    if (this.pos.y > height) {
      this.vel.y *= -1;
      this.pos.y = height;
    }
  }
  this.mouseDrag = function () {
    this.pos.x = mouseX;
    this.pos.y = mouseY;
  }
}


// FORCES

function Friction(obj, strength) {
  this.strength = strength;

  this.getFriction = function (obj) {
    let friction = obj.getVelocity();
    friction.normalize();
    friction.mult(-1);
    friction.mult(strength);
    return friction;
  }
  this.applyFriction = function (obj) {
    let friction = obj.getVelocity();
    friction.normalize();
    friction.mult(-1);
    friction.mult(strength);
    obj.applyForce(friction);
  }
}

function Gravity(constant) {
  this.constant = constant;

  this.getGravity = function (obj) {
    let gravity = createVector(0, this.constant);
    gravity.mult(obj.mass);
    return gravity;
  }
  this.applyGravity = function (obj) {
    let gravity = createVector(0, this.constant);
    gravity.mult(obj.mass);
  obj.applyForce(gravity);
  }
}

function Drag(density) {
  this.density = density;

  this.getDrag = function (obj) {
    let drag = obj.getVelocity();
    let speed = drag.mag();
    drag.normalize();
    drag.mult(-1);
    drag.mult(this.density*speed*speed);
    return drag;
  }
  this.applyDrag = function (obj) {
    let drag = obj.getVelocity();
    let speed = drag.mag();
    drag.normalize();
    drag.mult(-1);
    drag.mult(this.density*speed*speed);
    obj.applyForce(drag);
  }
}

function Spring(obj, anchor, length, strength) {
  this.str = strength;
  this.len = length;
  this.anchor = anchor;
  this.obj = obj;

  this.conn = function (limit) {
    //obj
    let force = this.obj.pos.copy();
    force.sub(anchor.pos);
    let dist = force.mag();
    let stretch = dist - this.len;

    force.normalize();
    force.mult(-1 * this.str * stretch);
    if (limit) {
      force.limit(limit);
    }
    obj.applyForce(force);
    //anchor
    let force2 = this.anchor.pos.copy();
    force2.sub(obj.pos);
    let dist2 = force2.mag();
    let stretch2 = dist2 - this.len;

    force2.normalize();
    force2.mult(-1 * this.str * stretch2);
    if (limit) {
      force2.limit(limit);
    }
    anchor.applyForce(force2);
  }
  this.show = function () {
    push();
    stroke(255);
    strokeWeight(1);
    line(obj.pos.x, obj.pos.y, anchor.pos.x, anchor.pos.y);
    pop();
  }
}
