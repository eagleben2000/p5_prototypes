function setup() {
  createCanvas(window.innerWidth, window.innerHeight);
}

function draw() {
  background(51);
}
