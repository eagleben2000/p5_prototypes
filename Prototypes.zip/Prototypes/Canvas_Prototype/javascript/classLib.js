// CLASS LIBRARY

// write your own classes here:





// PRESET CLASSES

// mouse
var mouse = {
  x: 0,
  y: 0,
  pos: []
}
window.addEventListener("mousemove", function(event){
  mouse.x  = event.x;
  mouse.y  = event.y;
  mouse.pos = [event.x, event.y];
});

// sound
function Sound(src) {
  this.sound = document.createElement("audio");
  this.sound.src = src;
  this.sound.setAttribute("preload", "auto");
  this.sound.setAttribute("controls", "none");
  this.sound.style.display = "none";
  document.body.appendChild(this.sound);
  this.play = function(loop, volume){
      this.sound.play();
      this.sound.loop = loop;
      this.sound.volume = volume;
  }
  this.stop = function(){
      this.sound.pause();
  }
}

// sprite
function Sprite(src, name) {
  this.sound = document.createElement("img");
  this.sound.src = src;
  this.sound.setAttribute("class", name);
  this.sound.style.display = "none";
  document.body.appendChild(this.sound);
  this.get = function(){
      return document.querySelector("." + name);
  }
}
