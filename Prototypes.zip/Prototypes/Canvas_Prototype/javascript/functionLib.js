// UTILITY FUNCTIONS

// write your own functions here:





// PRESET FUNCTIONS

function round(value, decimals) {
  return Number(Math.round(value+'e'+decimals)+'e-'+decimals);
}

function addVect(vect1, vect2) {
  for (i = 0; i < vect1.length; i++) {
      vect1[i] += vect2[i];
  }
  return vect1;
}

function multVect(vect1, vect2) {
  for (i = 0; i < vect1.length; i++) {
      vect1[i] *= vect2[i];
  }
  return vect1;
}

function getRndInteger(min, max) {
  return Math.floor(Math.random() * (max - min + 1) ) + min;
}
