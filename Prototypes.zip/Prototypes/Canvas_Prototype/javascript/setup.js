// global game variables
var difficulty;
var score;
var game;
var backgroundColor;

// start
$( document ).ready(function() {
  // init canvas
  var canvas = document.querySelector("canvas");
  var ctx  = canvas.getContext("2d");

  canvas.style = "background-color: " + backgroundColor + ";";
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;

  // init DOM-Objects
  var scoreOutput = document.querySelector(".score");

  // init Sounds
  var example = new Sound("sound/example.mp3");

  //init Sprites
  var example = new Sprite("img/example.mp3", "name");

  //init your Objects

  

  // init Aimation
  var frames = 0;
  function animate() {
  	requestAnimationFrame(animate);
    frames++;
  	ctx.clearRect(0, 0, innerWidth, innerHeight);
    // your animation code:



  	// output Score
    scoreOutput.innerHTML = score;
  }

  // start animation
  animate();
});
